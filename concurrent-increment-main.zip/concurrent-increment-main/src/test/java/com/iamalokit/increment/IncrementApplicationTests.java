package com.iamalokit.increment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IncrementApplicationTests {

	@Test
	void contextLoads() {
	}

}
